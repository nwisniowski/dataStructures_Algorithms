#include "node.h"
#include <iostream>

Node::Node()
{
    data_ = nullptr;
    left_child_ = nullptr;
    right_child_ = nullptr;
}

Node::Node(int data)
{
    data_ = new int(data);
    left_child_ = nullptr;
    right_child_ = nullptr;
}

int* Node::GetData(){
    return data_;
}

Node* Node::GetLeft(){
    return left_child_;
}

Node* Node::GetRight(){
    return right_child_;
}

void Node::SetData(int data){
    data_ = new int(data);
}

void Node::SetLeft(Node *newNode){
    left_child_ = newNode;
}

void Node::SetRight(Node *newNode){
    right_child_ = newNode;
}
void Node::InsertNode(Node* curr, int data) {

    if(!curr->GetData()){
        curr->SetData(data);
        return;
    }

    if(data < *(curr->GetData())){
        if(curr->GetLeft()){
            InsertNode(curr->GetLeft(), data);
        }else{
            curr->SetLeft(new Node(data));
        }
    }else{
        if(curr->GetRight()){
            InsertNode(curr->GetRight(), data);
        }else{
            curr->SetRight(new Node(data));
        }
    }
}

void Node::PrintTree(Node *curr, int depth){
    if(curr){
        std::cout<<depth<<": "<<*curr->data_<<std::endl;
        std::cout<<"Going Left from "<<*curr->GetData()<<std::endl;
        PrintTree(curr->left_child_, depth+1);
        std::cout<<"Going Right from "<<*curr->GetData()<<std::endl;
        PrintTree(curr->right_child_, depth+1);
    }else{
        std::cout<<"Null"<<std::endl;
        return;
    }
}

bool Node::IsDataPresent(Node* curr, int data){
    if(data < *(curr->GetData())){
        if(*curr->GetLeft()->GetData() == data){
            return true;
        }else{
            return IsDataPresent(curr->GetLeft(), data);
        }
    }else{
        if(curr->GetRight()){
            if(*curr->GetRight()->GetData() == data){
                return true;
            }else{
                return IsDataPresent(curr->GetRight(), data);
            }
        }
    }
    return false;
}


