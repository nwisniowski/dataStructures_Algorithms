#include "node.h"
#include "iostream"

int main()
{
    std::string UserInput;
    Node *root = new Node();

    root->InsertNode(root, 10);

    root->InsertNode(root, 5);

    root->InsertNode(root, 15);

    root->InsertNode(root, 13);

    root->PrintTree(root, 0);
    
    //Ask for and store user input
    std::cout<<"Enter an integer to check if it exists in this tree.\n";
    std::getline(std::cin, UserInput);
    
    //Convert str to int and check if it exists in the tree.
    //Convert bool return values to string output
    if(root->IsDataPresent(root, std::stoi(UserInput))==1){
        std::cout<<"Your entry exists in this tree.\n";
    }
    else std::cout<<"Your entry does not exist in this tree.\n";
}
