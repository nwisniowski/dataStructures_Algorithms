#ifndef NODE_H
#define NODE_H


class Node
{
public:
    Node();
    Node(int data);
    void InsertNode(Node* curr, int data);
    void PrintTree(Node *curr, int depth);

    bool IsDataPresent(Node* curr, int data);
    int* GetData();
    Node* GetLeft();
    Node* GetRight();

    void SetData(int data);
    void SetLeft(Node* newNode);
    void SetRight(Node* newNode);

private:
    int* data_;
    Node* left_child_;
    Node* right_child_;
};

#endif // NODE_H
