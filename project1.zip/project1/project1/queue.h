
#include <iomanip>
#include <iostream>
#include "node.h"

#ifndef Queue_h
#define Queue_h

class Queue{
    
public:
    //Queue class constructor and function prototypes
    Queue();
    void Enqueue(int cust_id, int arr_time, int serv_time);
    Node* Dequeue();
    void PrintQueue();
    int GetQueueSize();
    void GenerateQueue();
    void ServiceCustomer();
    Node* GetLeadingCustomer();
    
private:
    //Head and tail pointers, variable init
    Node *head_;
    Node *tail_;
    int queuesize_;
};

//Constructor initializes head and tail pointers
Queue::Queue(){
    this->head_= nullptr;
    this->tail_= nullptr;
    this->queuesize_=0;
    
}

//Add node to queue
void Queue::Enqueue(int cust_id, int arr_time, int serv_time){
    Node* newNode=new Node(cust_id, arr_time, serv_time);
    queuesize_=queuesize_+1;
    
    //If there is no head and tail then create them
    if (!this->head_){
        head_=newNode;
        tail_ = head_;
        return;
    }
    tail_->SetNext(newNode);
    tail_=newNode;
    
    std::cout<<"Customer "<<cust_id;
    std::cout<<" added to queue \n";
    
}

//Print queue
//Not using this
void Queue::PrintQueue(){
    Node* temp=this->head_;
    
    //Output stored data until temp is no longer valid
    while(temp){
        std::cout<<"Customer ID: "<<temp->GetCustID()<<"\n";
        std::cout<<"Arrival Time: "<<temp->GetArrTime()<<"\n";
        std::cout<<"Service Time: "<<temp->GetServTime()<<"\n";
        temp=temp->GetNext();
    }
    std::cout<<std::endl;
}

/*
Set temp to head
Decrement queue size
set head to next node
return temp for deletion in main
temp set to GetNext
delete temp
 */
Node* Queue::Dequeue(){
    Node* temp=this->head_;
    queuesize_=queuesize_-1;
    
    head_=head_->GetNext();
    
    std::cout<<"Customer "<<temp->GetCustID();
    std::cout<<" removed from line."<<std::endl;
    return temp;
}

int Queue::GetQueueSize(){
    return this->queuesize_;
}

void Queue::ServiceCustomer(){
    Node* temp=this->head_;
    
    temp->ServiceCustomer();
}

Node* Queue::GetLeadingCustomer(){
    return this->head_;
}

#endif /* Queue_h */
