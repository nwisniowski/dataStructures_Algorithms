//
//  main.cpp
//  project1
//
//  Created by NWisniowski on 2/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include <stdlib.h>
#include "node.h"
#include "queue.h"

#define MAXLINES '3'


int main() {
    srand(time(NULL)); //To make RNG work right
    
    //To manually increment total time
    std::string move;
    
    int cust_id=0;
    int cust_waited=0;
    int iterator;
    int smallestline=0;
    int total_time=0;
    int queuesizetracker=0;
    int maxcustwait=0;
    int maxcustwaiting=0;
    
    //Init max size variables
    int queuemaxsize[MAXLINES];
    for(int i=0; i<MAXLINES; i++){
        queuemaxsize[i]=0;
    }
    
    //Init queue pointers
    Queue* Lines[MAXLINES];
    Node* temp=nullptr;
    for(iterator=0; iterator<MAXLINES; iterator++){
        Lines[iterator] = new Queue();
    }
    
    //RNG for arrival time
    int arr_time=rand()%4+1;
    int serv_time=0;
    
    
    //Main logic begins here
    while(total_time<=720){
        
//        std::cout<<"Before first If\n";
//        std::cout<<"Cust ID: "<<cust_id<<std::endl;
//        std::cout<<"Arrival time: "<<arr_time<<std::endl;
        
        if(total_time == arr_time){
            //A customer has arrived.
            cust_id=cust_id+1;
            
            //Check which line is the smallest
            for(iterator=0; iterator<3; iterator++){
                if(Lines[iterator]->GetQueueSize()<Lines[smallestline]->GetQueueSize()){
                    smallestline=iterator;
                }
                
            }
            //RNG for service time
            serv_time=rand()%4+1;
            
            //Enqueue a customer
            std::cout<<"Cust ID: "<<cust_id<<std::endl;
            std::cout<<"Arrival time: "<<arr_time<<std::endl;
            Lines[smallestline]->Enqueue(cust_id, arr_time, serv_time);

            //RNG for arrival time
            arr_time=total_time+rand()%4+1;
        }
        
        //Service and dequeue customers in each line
        for(iterator=0; iterator<3; iterator++){
            
//            std::cout<<iterator;
//            std::cout<<MAXLINES;
            queuesizetracker=Lines[iterator]->GetQueueSize();
            
            if(queuesizetracker>queuemaxsize[iterator]){
                queuemaxsize[iterator]=queuesizetracker;
            }
            std::cout<<"Queue "<<iterator;
            std::cout<< " size: "<<queuesizetracker<<std::endl;
            
            if(Lines[iterator]->GetQueueSize()!=0){
//                temp2=Lines[i]->GetQueueSize();
                std::cout<<"Service time: "<<serv_time<<std::endl;
                Lines[iterator]->ServiceCustomer();
                
                //Store head_ data in temp
                temp=Lines[iterator]->GetLeadingCustomer();
                
                //Dequeue if service time is 0
                if(temp->GetServTime()==0){
                    temp=Lines[iterator]->Dequeue();
                    
                    //Calculate customer wait time
                    cust_waited=total_time-temp->GetArrTime();
                    std::cout<<"Customer waited "<<cust_waited<<" minutes"<<std::endl;
                    
                    //Keep track of longest wait time
                    if(cust_waited>maxcustwait){
                        maxcustwait=cust_waited;
                    }
                    
                    delete temp;
                }
            }
        }

        total_time=total_time+1;
        std::cout<<total_time<<std::endl;
    }

    //Print how big queues got
    for(iterator=0; iterator<3; iterator++){
        maxcustwaiting+=queuemaxsize[iterator];
        std::cout<<"Queue "<<iterator<<" max size "<<queuemaxsize[iterator]<<std::endl;
    }
    
    //Print max customers in line and max wait time
    std::cout<<"Max customers waiting in line: "<<maxcustwaiting<<std::endl;
    std::cout<<"Max customer wait time: "<<maxcustwait<<std::endl;
    return 0;
}

