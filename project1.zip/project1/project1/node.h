#ifndef NODE_H
#define NODE_H


class Node{
public:
    //Node class constructor and function prototypes
    Node(int cust_id, int arr_time, int serv_time);
    void SetNext(Node *next);
    Node* GetNext();
    int GetCustID();
    int GetArrTime();
    int GetServTime();
    void PrintNode();
    void ServiceCustomer();
    
private:
    //Input data and next node pointer variables
    int cust_id_;
    int arr_time_;
    int serv_time_;
    Node *next_;
};

//Constructor intitializing data variables and next pointer
Node::Node(int cust_id, int arr_time, int serv_time){
    this->cust_id_ = cust_id;
    this->arr_time_= arr_time;
    this->serv_time_= serv_time;
    this->next_ = nullptr;
}

//Return customer ID a node
int Node::GetCustID(){
    return this->cust_id_;
}

//Return arrival time from a node
int Node::GetArrTime(){
    return this->arr_time_;
}

//Return service time from a node
int Node::GetServTime(){
    return this->serv_time_;
}

//Return  from a node
Node* Node::GetNext(){
    return this->next_;
}

//Function to set the next pointer to the next node
void Node::SetNext(Node *next){
    this->next_= next;
}

//Print node
//Not using this
void Node::PrintNode(){
        std::cout<<"Customer ID: "<<this->GetCustID()<<"\n";
        std::cout<<"Arrival Time: "<<this->GetArrTime()<<"\n";
        std::cout<<"Service Time: "<<this->GetServTime()<<"\n";
        std::cout<<std::endl;
}

//Function decrementing service time
void Node::ServiceCustomer(){
    serv_time_=serv_time_-1;
}

#endif // NODE_H
