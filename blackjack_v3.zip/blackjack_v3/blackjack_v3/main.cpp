#include "dealer.h"
#include "card.h"
#define MAXPLAYERS 7

/*
 To fix:
 DONE Always hits on 1st return
 DONE No cards at start
 DONE 21 on first deal should pay out
 DONE Check for valid user input
 Ace must drop to 1 point if dealt a card and bust (possibly multiple aces in one hand)
 Multiple players (max 8)
 User friendly input
 Multiple rounds
 */

int main(){
    srand(time(NULL));
    
    
    Player* player = new Player();
    Dealer* dealer = new Dealer();
    
    std::string playerChoice;
    
    //Init deal and print hand
    for(int i = 0; i<2; i++){
        
        player->AddCard(dealer->DealCard());
        dealer->AddCard(dealer->DealCard());
    }
    
    player->PrintHand();
    dealer->PrintCard();
    
    
//    For testing aces
//    player->AddCard(new Card("TEST", 10, "TEST"));
//    player->AddCard(new Card("TEST", 11, "TEST"));

    if(player->GetScore()!=21){
        std::cout<<"\nENTER to hit, 's' to stay ";
        std::getline(std::cin, playerChoice);
        
        while(playerChoice != "s"){
            
            std::cout<<"Hit\n";
            player->AddCard(dealer->DealCard());
            player->PrintHand();
            
            if(player->GetScore() > 21){
                
                if(player->HasAce()==true){
                    
                    std::cout<<"Ace Logic Loop"<<std::endl;
                    
                    player->ReduceAce();
                    player->PrintHand();
//                    std::cout<<"Bust! You lose!"<<std::endl;
                }
                else{
                    std::cout<<"Bust!"<<std::endl;
                }
            }
            else{
                std::cout<<"\nENTER to hit, 's' to stay ";
                std::getline(std::cin, playerChoice);
            }
            
//Break

//            else std::cout<<"\nENTER to hit, 's' to stay ";
//            std::getline(std::cin, playerChoice);
        }
        
        dealer->TakeTurn(player->GetScore());
        
        std::cout<<std::endl<<"Player's Score: "<<player->GetScore()<<std::endl;
        std::cout<<"Dealer's Score: "<<dealer->GetScore()<<std::endl<<std::endl;
        
        if(dealer->GetScore() > 21 || (player->GetScore() > dealer->GetScore())){
            std::cout<<"You win!"<<std::endl;
        }
        
        else{
            std::cout<<"You lose!"<<std::endl;
        }
    }
    else{
        std::cout<<"You win!\n";
    }
    

//    std::cout<<"Blackjack!\n";
//    std::cout<<"You win!"<<std::endl;
}
