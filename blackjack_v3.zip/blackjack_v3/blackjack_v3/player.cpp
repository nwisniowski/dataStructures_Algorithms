#include "player.h"

Player::Player()
{
    score_ = 0;
}

void Player::PrintHand(){
    std::cout<<"Player's Hand"<<std::endl;
    for(int i = 0; i < hand_.size(); i++){
        hand_.at(i)->PrintCard();
    }
    std::cout<<"Score: "<<score_<<std::endl;
}

void Player::AddCard(Card* newCard){
    hand_.push_back(newCard);
    score_ += newCard->GetValue();
}

bool Player::HasAce(){
    for(int i = 0; i < hand_.size(); i++){
        hand_.at(i)->PrintCard();
        if(hand_.at(i)->GetFace()=="Ace"){
            return true;
        }
    }
    return false;
}

void Player::ReduceAce(){
    score_ -= 10;
    std::cout<<"Ace reduced"<<std::endl;
}

int Player::GetScore(){
    return score_;
}
