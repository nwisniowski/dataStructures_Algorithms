//
//  Header.h
//  Lab1_Q2
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#ifndef Header_h
#define Header_h


#endif /* Header_h */
