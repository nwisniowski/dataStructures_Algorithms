//
//  main.cpp
//  Lab1_Q2
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "q2.h"

int main()
{
    Q2::printInOrderVertically(84172);
    std::cout<<std::endl;
    Q2::printReverseVertically(84172);
    std::cout<<std::endl;
}
