//
//  q2.cpp
//  Lab1_Q2
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "q2.h"



 int Q2::printInOrderVertically(int digit){
    if (digit==0){
        return digit;
    }std::cout<<digit%10<<std::endl;
    return printInOrderVertically(digit/10);
}



int Q2::printReverseVertically(int digit){
    if (digit==0){
        return 0;
    }std::cout<<digit%10<<std::endl;
    return printReverseVertically(digit/10);
//    return printVertically(counter-1, digit/10);
}
