//
//  q2.h
//  Lab1_Q2
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#ifndef q2_h
#define q2_h
class Q2{
public:
    static int printInOrderVertically(int digit);
    static int printReverseVertically(int digit);
private:
    
};

#endif /* lab1_h */
