//
//  main.cpp
//  sort_hw
//
//  Created by NWisniowski on 4/6/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include "sort.h"
#include <iostream>

int main(){
    
    int arr[MAXSIZE]={6, 5, 9, 4, 2, 7, 1};
    
    Sort::QuickSort(arr, 1, sizeof(arr));
    
return 0;
}
