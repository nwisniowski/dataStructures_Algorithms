//
//  sort.h
//  sort_hw
//
//  Created by NWisniowski on 4/6/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#define MAXSIZE 7
#ifndef sort_h
#define sort_h

class Sort{

public:
    void QuickSort(int arr, int lo, int hi);
    int Partition(int arr, int lo, int hi);
    int arr[MAXSIZE];
    
private:
    
};

void Sort::QuickSort(int arr, int lo, int hi){
    
    std::cout<<arr<<std::endl;
    
    if (lo<hi){
        int p=Partition(arr, lo, hi);
        Sort::QuickSort(arr, lo, p-1);
        Sort::QuickSort(arr, p + 1, hi);
    }
    std::cout<<std::endl<<arr<<std::endl;
}

int Sort::Partition(int arr, int lo, int hi){
    int pivot=arr[hi];
    int i=lo-1;
    
    for(int j=lo; j<hi-1; j++){
        if(arr[j] <= pivot){
            i=i+1;
            //Swap arr[i] with arr[j]
        }
    }
    //Swap arr[i+1] with arr[hi]
    //Return i + 1
}


#endif /* sort_h */
