#include "calculator.h" //Contains the definitions for all of the functions

//Constructor
Calculator::Calculator()
{
    //Example on how to use GetOperands and handle pointer return
    /*float *a = GetOperands("this is a string literal");
    std::cout<<a[0]<<std::endl;
    std::cout<<a[1]<<std::endl;
    //Destroy the array we created
    delete a;
    */
}

//Used to start the calculator loop, accepts equations until QUIT is entered.
void Calculator::Run(){
    //Get an initial input from the user, check to see if it is QUIT
    //Note: This makes it so we only have 1 check in the loop
    //The while() takes care of every other attempt to quit
    std::string userInput = GetUserInput();
    if(userInput != "QUIT"){
        do{
            std::cout << Evaluate(GetOperator(userInput), GetOperands(userInput));
        }while((userInput = GetUserInput()) != "QUIT");
    }
}

//Get & validate user input
std::string Calculator::GetUserInput(){
    char userInput[kInputBufferSize];

    std::cout<<"Enter an equation, QUIT to stop: ";

    //Retrieve only as much data from the input buffer as our variable can hold
    std::cin.getline(userInput, kInputBufferSize);

    //Clears any error flag set off in the input buffer & discard everything left in the buffer
    //Play around with this. kInputBufferSize is set to 20.
    //What happens when you enter 19 characters?
    //What happens when you enter 20 characters?
    //Uncomment the 2 lines below this one, repeat the above tests.
    //std::cin.clear();
    //std::cin.sync();

    //Returns the equation to Run()
    //TODO: Ensure input is in the proper format.
    return userInput;
}

//Evaluates the expression
float Calculator::Evaluate(char op, float *operands){
    //TODO: Use the given "op" variable to decide which operation to perform
    //return the result of that operation

    //Dummy Return
    return 0.0;
}

//Parse the input, return the operator
char Calculator::GetOperator(std::string UserInput){
    //TODO: Parse though the string and return the operator being used

    //Dummy Return
    return UserInput[0];
}

//Parse the input, return an array containing the operands
float* Calculator::GetOperands(std::string UserInput){
    //TODO: Parse though the string and return the operator being used

    //Example to show how to dynamically create an array, fill it, and return it
    float *operands = new float[2];

    /*

    operands[0] = 5.0;
    operands[1] = 2.2;
    */
    return operands;

}












