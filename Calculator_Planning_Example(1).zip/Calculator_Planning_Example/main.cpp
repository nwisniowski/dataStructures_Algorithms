#include <stdio.h>
#include "calculator.h"

int main(){
    Calculator *calc = new Calculator();

    calc->Run();
}

