#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <iostream> //IO
//#include <string>   //
#include <limits>   //Needed to c
class Calculator
{
public:
    Calculator();

    void Run();

    std::string GetUserInput();

    float Evaluate(char op, float *operands);

    char GetOperator(std::string UserInput);
    float* GetOperands(std::string UserInput);

private:
    const int kInputBufferSize = 20;
};

#endif // CALCULATOR_H
