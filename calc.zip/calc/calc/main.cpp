//
//  main.cpp
//  calc
//
//  Created by NWisniowski on 1/25/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
