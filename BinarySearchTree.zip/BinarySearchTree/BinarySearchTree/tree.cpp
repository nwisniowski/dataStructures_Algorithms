#include "tree.h"

//DO NOT TOUCH
Tree::Tree()
{
    root_ = nullptr;
}

//DO NOT TOUCH
void Tree::AddNode(int key){
    if(!root_){
        root_ = new Node(key);
    }else{
        AddNode(root_, key);
    }
}

void Tree::AddNode(Node* curr, int key){
    //Implement this recursive function
    Node* newNode=new Node(key);
    
    if(key < curr->GetKey()){
        curr->SetLeft(newNode);
    }
    curr->SetRight(newNode);
}

//DO NOT TOUCH
void Tree::PrintInOrder(){
    PrintInOrder(root_);
}

void Tree::PrintInOrder(Node* curr){
    //Implement this recursive function
    
//    int lowestKey = 0;
    
//    while (curr->GetKey()) {
//        std::cout<<std::endl<<"Current Key "<<curr->GetKey();
//        PrintInOrder(curr->GetLeft());
//        PrintInOrder(curr->GetRight());
        

//    }

    std::cout<<curr->GetKey()<<" ";
}

//DO NOT TOUCH
void Tree::PrintPostOrder(){
    PrintPostOrder(root_);
}

void Tree::PrintPostOrder(Node* curr){
    //Implement this recursive function
}

//DO NOT TOUCH
void Tree::PrintPreOrder(){
    PrintPreOrder(root_);
}

void Tree::PrintPreOrder(Node* curr){
    //Implement this recursive function
    
}

//DO NOT TOUCH
void Tree::PrintRevOrder(){
    PrintRevOrder(root_);
}

void Tree::PrintRevOrder(Node* curr){
    //Implement this recursive function
}

//DO NOT TOUCH
Node* Tree::SearchTree(int key){
    return SearchTree(root_, key);
}

Node* Tree::SearchTree(Node* curr, int key){
    //Implement this recursive function
    while(key!=curr->GetKey()){ //While key is not curr's key
        if(key < curr->GetKey()){   //If key less than curr's key
            curr=curr->GetLeft();   //Set curr to left
            SearchTree(curr, key);  //Call search tree with new curr
        }
        curr=curr->GetRight();  //Else set curr to right
        SearchTree(curr, key);  //Call search tree with new curr
    }
    return curr;
}

//DO NOT TOUCH
Node* Tree::FindMin(){
    return FindMin(root_);
}

Node* Tree::FindMin(Node* curr){
    //Implement this recursive function
    
    while(curr->GetLeft()){ //While left node exists
            curr = curr->GetLeft(); //Set new curr
            FindMin(curr);    //Call find min with new curr
        
    }
    return curr;
}

//DO NOT TOUCH
Node* Tree::FindMax(){
    return FindMax(root_);
}

Node* Tree::FindMax(Node* curr){
    //Implement this recursive function
 
    while(curr->GetRight()){ //While right node exists
        curr = curr->GetRight(); //Set new curr
        FindMin(curr);    //Call find min with new curr
        
    }
    return curr;
}
