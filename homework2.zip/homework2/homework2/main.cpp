#include "node.h"
#include "list.h"
#include "iostream"
#include <stack>

//Function prototypes
void GetUserInput();
bool IsInt(std::string UserInput);
bool IsDouble(std::string UserInput);
bool IsChar(std::string UserInput);
bool isPalindrome();

int main(){
    
    //Function call for problem 1
    GetUserInput();
    
    //Coverts bool values returned from isPalindrome to string output
    if(isPalindrome()==1){
        std::cout<<"This string is a palindrome.\n";
    }
    else std::cout<<"This string is NOT a palindrome.\n";

    
}   //End of main


//Function to prompt user for data, add it to an appropriate list and then print it
void GetUserInput(){
    
    std::string UserInput;
    List<int>* intList = new List<int>();
    List<double>* doubleList = new List<double>();
    List<char>* charList = new List<char>();
    List<std::string>* stringList = new List<std::string>();
    
    //Prompt user for input and set it to UserInput variable
    std::cout<<"Enter data of one type\nEnter -1 to quit program";
    std::getline(std::cin, UserInput);
    
    //        std::cout<<"Input:"<<UserInput;
    //        std::cout<<"TEST";
    
    //While input is not kill and if not empty str, check if input is an int, then double, then char, else it's a string
    while (UserInput!="-1"){
        
        if(UserInput==""){
            std::cout<<"Input is invalid";
        }
        else if(IsInt(UserInput)){
            intList->AddNode(std::stoi(UserInput));
        }
        else if(IsDouble(UserInput)){
            doubleList->AddNode(std::stod(UserInput));
        }
        else if(IsChar(UserInput)){
            charList->AddNode(UserInput[0]);
        }
        else stringList->AddNode(UserInput);
        
        //Prints data in each list
        std::cout<<std::endl<<"Integer List: ";
        intList->PrintList();
        std::cout<<"Double List: ";
        doubleList->PrintList();
        std::cout<<"Character List: ";
        charList->PrintList();
        std::cout<<"String List: ";
        stringList->PrintList();
        
        //Reprompts user for input
        std::cout<<std::endl<<"Enter data of one type\n";
        std::getline(std::cin, UserInput);
    }
    
}

//Check if UserInput is an integer
bool IsInt(std::string UserInput){
    
    
    for(int iterator = 0; UserInput[iterator] != '\0'; iterator++){
        
        if(!isdigit(UserInput[iterator])){  //If not a digit
            return false;
        }
    }return true;
}

//Check if UserInput is a double
bool IsDouble(std::string UserInput){
    
    
    for(int iterator = 0; UserInput[iterator] != '\0'; iterator++){
        
        if(!isdigit(UserInput[iterator])){  //If not a digit
            if(!(UserInput[iterator]=='.')){    //if not a period
                return false;
            }
        }
    }return true;
}

//Check if UserInput is a character
bool IsChar(std::string UserInput){
    
    if(UserInput.length()==1){  //If string length is 1
        return true;
    }return false;
    
}

//Function to check if user input is a palindrome
bool isPalindrome(){
    std::string PalUserInput;
    std::stack<char> PalStack;
    int iterator = 0;
    
    std::cout<<"Enter a string\n";
    std::getline(std::cin, PalUserInput);
    
    long int StrLen=PalUserInput.length();
    
    for(;iterator < StrLen/2; iterator++){
        PalStack.push(PalUserInput[iterator]);
    }
    
    if(PalUserInput.length()%2==1){
        iterator++;
    }
    
    for(; iterator < StrLen; iterator++){
//        std::cout<<PalStack.top()<<" "<<PalUserInput[iterator]<<std::endl;
        if(PalStack.top() != PalUserInput[iterator]){
            return false;
        }
        PalStack.pop();
    }
    return true;
}

