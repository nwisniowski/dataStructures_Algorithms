#ifndef NODE_H
#define NODE_H

template<class T>
class Node{
    
public:
    //Node class constructor and function prototypes
    Node(T data);
    void SetNext(Node<T> *next);
    Node<T>* GetNext();
    T GetData();
private:
    //Input data and next node pointer variables
    T data_;
    Node<T> *next_;
};

//Constructor intitializing data variable and next pointer
template<class T>
Node<T>::Node(T data){
    this->data_ = data;
    this->next_ = nullptr;
}

//Function to return data in a node
template<class T>
T Node<T>::GetData(){
    return this->data_;
}

//Function to return the next node in the list
template<class T>
Node<T>* Node<T>::GetNext(){
    return this->next_;
}

//Function to set the next pointer to the next node
template<class T>
void Node<T>::SetNext(Node<T> *next){
    this->next_= next;
}

#endif // NODE_H
