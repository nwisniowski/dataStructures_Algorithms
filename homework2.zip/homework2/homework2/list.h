//
//  List.h
//  homework2
//
//  Created by NWisniowski on 2/16/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "Node.h"
#include <iomanip>

#ifndef List_h
#define List_h

template<class T>
class List{
    
public:
    //List class constructor and function prototypes
    List();
    void AddNode(T data);
    void RemoveNode();
    void PrintList();
    
private:
    //Head and tail pointers
    Node<T> *head_;
    Node<T> *tail_;
};

//Constructor initializes head and tail pointers
template<class T>
List<T>::List(){
    this->head_= nullptr;
    this->tail_= nullptr;
}

//Add node to list
template <class T>
void List<T>::AddNode(T data){
    Node<T>* newNode=new Node<T>(data);
    
    //If there is no head and tail then create them
    if (!this->head_){
        head_=newNode;
        tail_=head_;
        return;
    }
    
    tail_->SetNext(newNode);
    tail_=newNode;
}

//PrintList function
//Make temp ptr that points to head, print then move temp along and print again.
template<class T>
void List<T>::PrintList(){
    
    Node<T>* temp=this->head_;
    
    //Output stored data until temp is no longer valid
    while(temp){
        std::cout<<std::setprecision(2)<<std::fixed<<temp->GetData()<<" ";
        temp=temp->GetNext();
    }
    std::cout<<std::endl;
}

//template <class T>
//void List<T>::RemoveNode(){
//    Node<T>* temp=this->head;
//    Node<T>* temp2=nullptr;
//    
//    while(temp && temp->GetData()!=data_){
//        temp2=temp;
//        temp=temp->GetNext();
//    }
//    temp2->setNext(temp->GetNext());
//    delete temp;
//}

#endif /* List_h */
