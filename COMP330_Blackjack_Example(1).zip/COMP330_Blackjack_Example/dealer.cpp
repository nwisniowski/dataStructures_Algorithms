#include "dealer.h"

Dealer::Dealer()
{

}
