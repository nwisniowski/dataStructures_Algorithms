//
//  q3.cpp
//  Lab1
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include "lab1.h"

//void lab1::printTriangle(int row){
//    lab1::printTriangleRecursively(int row, int initial);
//}


//Recursive function to print an equilateral triangle
int lab1::printTriangleRecursively(int rowToPrint, int NUMROWS){
    
    
    //Trying to determine where the breakpoint error occurs with these cout statements
//    std::cout<<"FAILED 1";
    if (rowToPrint>NUMROWS) {
//        std::cout<<"FAILED 2";
        return 0;
    }//std::cout<<"FAILED 3";
//    std::cout<<std::endl;   //If I comment this out, the program doesn't function completely
    
    int numBlanks=NUMROWS-rowToPrint;
    int numStars=rowToPrint*2-1;
    
    //For loops for printing either a space or an X
    for (int i=0; i<(numBlanks); i++) {
        std::cout<<" ";
    }
    for (int i=0; i<numStars; i++) {
        std::cout<<"X";
    }
    std::cout<<std::endl;
    
    lab1::printTriangleRecursively(rowToPrint+1, NUMROWS); //Here is the recursive call
    return 1;
}


//    if(row==0){
//        return 0;
//    }std::cout<<row;
//    for (row=0; row<11; ++row) {
//        std::cout<<row;
//        std::cout<<"X";
    

//    return printTriangle(row-1);
//}

//int lab1::printSpace(int row){
//    if(row==0){
//        return 0;
//    }std::cout<<" ";
//    return printSpace(row-1);
//}

//int lab1::printX(int row){
//    if(row==0){
//        return 0;
//    }std::cout<<"X";
//    return printX(row-1);
//}
