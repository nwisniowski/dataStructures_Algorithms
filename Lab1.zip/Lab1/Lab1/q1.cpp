//
//  q1.cpp
//  Lab1
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include "lab1.h"

//Recursive function to compute factorial of a given number defined in main
int lab1::factorial(int n, int product)
{
    
    if(n == 0){
        return product;
    }return factorial(n - 1, product * n);  //Decrement digit, multiply and recursive call
    
    
}
