//
//  main.cpp
//  Lab1
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "lab1.h"


int main()
{
    std::cout<<lab1::factorial(6,1)<<std::endl<<std::endl; //Print the result of the factorial function in q1
    lab1::printInOrderVertically(84172);    //Call the printInOrderVertically function in q2
    std::cout<<std::endl;
    lab1::printReverseVertically(84172);    //Call the printReverseVertically function in q2
    std::cout<<std::endl;
    lab1::printTriangleRecursively(1,5);  //Call the printRow function in q3
}
