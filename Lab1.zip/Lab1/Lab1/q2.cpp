//
//  q2.cpp
//  Lab1
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "lab1.h"


//Recursive function to print each digit of a number on a new line
int lab1::printInOrderVertically(int digit){
    if (digit==0){
        return digit;
    }
    printInOrderVertically(digit/10);   //Recusrive call with the result of digit divided by 10
    std::cout<<digit%10<<std::endl; //Print digit modulus 10
    
    return 0;
    
}

//Recursive function to print each digit of a number on a new line but in reverse order
int lab1::printReverseVertically(int digit){
    if (digit==0){
        return 0;
    }std::cout<<digit%10<<std::endl;    //Print digit modulus 10
    return printReverseVertically(digit/10);    //Recursive call with the result of digit divided by 10

}
