//
//  lab1.h
//  Lab1
//
//  Created by NWisniowski on 1/26/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#ifndef lab1_h
#define lab1_h

//Class definition for functions used in Lab 1
class lab1{
public:
    //Q1 functions
    static int factorial(int n, int product);
    //Q2 functions
    static int printInOrderVertically(int digit);
    static int printReverseVertically(int digit);
    //Q3 functions
    const int NUMROWS = 10;
//    static int printX(int X);
//    void printTriangle(int row);
    static int printTriangleRecursively(int rowToPrint, int NUMROWS);
private:
    
};

#endif /* lab1_h */
