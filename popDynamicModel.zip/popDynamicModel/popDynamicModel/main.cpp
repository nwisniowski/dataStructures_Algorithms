#include <string>
#include <iostream>
#include <time.h>

using namespace std;

#define MAX_COL 5       // Number of ocean squares "across"
#define MAX_ROW 5       // Number of ocean squares "down"

#define PSHARK  30      // Probability value that the animal is a SHARK
#define PFISH   30      // Probability value that the animal is a FISH
#define RSHARK  30     // Probability that a shark will reproduce
#define RFISH   30     // Probability that a fish will reproduce
#define STARVE  5       // Number of months that a SHARK will die of starvation if it doesnt eat

// Forward declarations of methods used in this program
void GenerateOcean();
void PrintOcean(int nMonth);
void CopyOceantoNextOcean();
void CopyNextOceanBackToOcean();
void doMovements();
void MoveFish(int nOldRow, int nOldCol);
void MoveShark(int nOldRow, int nOldCol);
int GetRandomDirection (int nOldRow, int nOldCol, int &nNewRow, int &nNewCol, string &sDirection);
void GetPollutedRegion();

// Global variables used to detect/store polluted region
int nPollutedRowTop = -1;
int nPollutedColTop = -1;
int nPollutedRowBot = -1;
int nPollutedColBot = -1;

// Declare the class for animal
// Methods are in this source member, after main()...
class Animal
{
public:
    bool m_bIsAFish; //class datamember, is true if this is a FISH
    bool m_bIsAShark; //class datamember, is true if this is a SHARK
    bool m_bIsEmpty; //class datamember, is true if this is empty
    bool m_bIsChild; //class datamember, is true if this Animal is a child
    int  m_nMonthsToLive; //class datamember, contains the number of months this thing will live (if it doesnt eat)
    char m_cAnimalType; //class datamember, contains the ASCII character of the animal used for printout
    void m_Print(); //Class member functions used to print out the type of animal
    void m_MakeItEmpty(); // This sets up the Animal to be "Empty"
    Animal();  // Class constructor - uses random number to create SHARKS or FISHES or EMPTY
};

// Declare global variables used in the program
long nRandomNumberSeed = 0;  // Use this global variable for the random number seed (uses time(NULL))
Animal OCEAN[MAX_ROW][MAX_COL]; // Use this global array for the OCEAN
Animal NEXTOCEAN[MAX_ROW][MAX_COL]; // Use this global array as staging for animal movement

int main()
{
    
    int nMonths = 0;
    
    // Perform initialization functions
    
    //"Seed" the random number generator used for the program
    nRandomNumberSeed = time(NULL);
    srand (nRandomNumberSeed); // see documentation for use of srand() with rand()
    
    // print the header
    cout << "Program: Sharks and Fishes" << endl << endl;
    
    // Collect the info if the user wants to specify a polluted region
    GetPollutedRegion();
    
    // Collect the user input for the number of months
    cout << "How many months do you want to run the simulator for?: ";
    cin >> nMonths;
    
    // Generate an ocean full of "Animals" (sharks, fishes, and blank squares)
    cout << endl << "Initial Ocean:";
    GenerateOcean();
    PrintOcean(0);
    
    for (int nMonth=1;nMonth <= nMonths; nMonth++)
    {
        CopyOceantoNextOcean();
        doMovements();
        CopyNextOceanBackToOcean();
        PrintOcean(nMonth);
    }
    return 0;
}

void GenerateOcean()
{
    for (int row=0;row<MAX_ROW;row++)
    {
        for (int col=0;col<MAX_COL;col++)
        {
            Animal TempAnimal;
            OCEAN[row][col] = TempAnimal;
        }
    }
}

void PrintOcean(int nMonth)
{
    int nSharks = 0;
    int nFish = 0;
    
    cout << endl << "Ocean state, month " << nMonth;
    for (int row=0;row<MAX_ROW;row++)
    {
        cout << endl;
        for (int col=0;col<MAX_COL;col++)
        {
            OCEAN[row][col].m_Print();
            if (OCEAN[row][col].m_bIsAFish)
                nFish++;
            if (OCEAN[row][col].m_bIsAShark)
                nSharks++;
        }
    }
    // Report the number of fish and sharks
    cout << endl << nFish << " fish, " << nSharks << " sharks" << endl;
}

void CopyOceantoNextOcean()
{
    for (int row=0;row<MAX_ROW;row++)
    {
        for (int col=0;col<MAX_COL;col++)
        {
            NEXTOCEAN[row][col] = OCEAN[row][col];
        }
    }
}

void CopyNextOceanBackToOcean()
{
    for (int row=0;row<MAX_ROW;row++)
    {
        for (int col=0;col<MAX_COL;col++)
        {
            OCEAN[row][col] = NEXTOCEAN[row][col];
        }
    }
}

void doMovements()
{
    for (int row=0;row<MAX_ROW;row++)
    {
        for (int col=0;col<MAX_COL;col++)
        {
            if (OCEAN[row][col].m_bIsAFish)
            {
                MoveFish(row,col);
            }
            else if (OCEAN[row][col].m_bIsAShark)
            {
                MoveShark(row,col);
            }
        }
    }
}

// This returns either a value of 0-3 for the random direction, also populates some references on the
// argument list for the new row/col and descriptive string for the direction.
// -1 is returned if the move in the random direction is off the grid.
int GetRandomDirection (int nOldRow, int nOldCol, int &nNewRow, int &nNewCol, string &sDirection)
{
    //Initialize local variables
    nNewRow = 0;
    nNewCol = 0;
    sDirection = "";
    
    //Get random direction
    int nDirection = rand()%4;
    
    //Calculate new coordinates in that direction
    if (nDirection == 0) //left
    {
        nNewCol = nOldCol - 1;
        nNewRow = nOldRow;
        sDirection = "left";
    }
    else if (nDirection == 1) //right
    {
        nNewCol = nOldCol + 1;
        nNewRow = nOldRow;
        sDirection = "right";
    }
    else if (nDirection == 2) //up
    {
        nNewCol = nOldCol;
        nNewRow = nOldRow - 1;
        sDirection = "up";
    }
    else if (nDirection == 3) //down
    {
        nNewCol = nOldCol;
        nNewRow = nOldRow + 1;
        sDirection = "down";
    }
    
    // Validate that the move is on the grid
    if ((nNewCol < 0) || (nNewCol >= MAX_COL) || (nNewRow < 0) || (nNewRow >= MAX_ROW) )
    {
        nDirection = -1;
    }
    
    return nDirection;
}

void MoveFish(int nOldRow, int nOldCol)
{
    int nNewRow = 0;
    int nNewCol = 0;
    string sDirection = "";
    
    // A return of -1 means the move would take us off the grid - so stay put!
    // NOTE: This function uses references to the ints(nNewRow, nNewCol) and the sting (sDirection)
    //       Doing this allows the function to set these variables and pass them back
    //       See the forward declaration for "GetRandomDirection" at the top of the program to see this definition
    if (GetRandomDirection(nOldRow, nOldCol, nNewRow, nNewCol, sDirection) != -1)
    {
        // if the spot is the polluted region, the fish dies
        if (nNewRow >= nPollutedRowTop && nNewRow <= nPollutedRowBot &&
            nNewCol >= nPollutedColTop && nNewCol <= nPollutedColBot)
        {
            cout << endl << "fish at row:" << nOldRow << ", col:" << nOldCol << " died cuz he got polluted!";
            NEXTOCEAN[nOldRow][nOldCol].m_MakeItEmpty();
        }
        // Check to see if the spot is empty, if so - WE CAN MOVE!
        else if (NEXTOCEAN[nNewRow][nNewCol].m_bIsEmpty)
        {
            cout << endl << "Moving fish from row:" << nOldRow << ", col:" << nOldCol << " " << sDirection;
            
            // Set the months to live for the fish
            NEXTOCEAN[nNewRow][nNewCol].m_nMonthsToLive = NEXTOCEAN[nOldRow][nOldCol].m_nMonthsToLive;
            // Make the new square a Fish
            NEXTOCEAN[nNewRow][nNewCol].m_bIsAShark = false;
            NEXTOCEAN[nNewRow][nNewCol].m_bIsAFish = true;
            NEXTOCEAN[nNewRow][nNewCol].m_bIsEmpty = false;
            NEXTOCEAN[nNewRow][nNewCol].m_cAnimalType = 'F';
            
            // Check if we should reproduce, and leave some spawn behind
            int nShouldReproduce = rand()%100;
            if (nShouldReproduce < RFISH)
            {
                NEXTOCEAN[nOldRow][nOldCol] = NEXTOCEAN[nNewRow][nNewCol];
                NEXTOCEAN[nOldRow][nOldCol].m_bIsChild = true;
                cout << " - Reproduce!";
            }
            else
            {
                NEXTOCEAN[nOldRow][nOldCol].m_MakeItEmpty(); //  Empty out the "old" square
            }
        }
    }
}

void MoveShark(int nOldRow, int nOldCol)
{
    int nNewRow = 0;
    int nNewCol = 0;
    string sDirection = "";
    
    NEXTOCEAN[nOldRow][nOldCol].m_nMonthsToLive--;
    
    // Shark has died cuz his time ran out!
    if(NEXTOCEAN[nOldRow][nOldCol].m_nMonthsToLive < 0)
    {
        cout << endl << "shark at row:" << nOldRow << ", col:" << nOldCol << " died!";
        NEXTOCEAN[nOldRow][nOldCol].m_MakeItEmpty();
    }
    else
    {
        cout << endl << "shark at row:" << nOldRow << ", col:" << nOldCol << " has " << NEXTOCEAN[nOldRow][nOldCol].m_nMonthsToLive << " Months left!";
        
        // A return of -1 means the move would take us off the grid - so stay put!
        // NOTE: This function uses references to the ints(nNewRow, nNewCol) and the sting (sDirection)
        //       Doing this allows the function to set these variables and pass them back via the argument list
        //       See the forward declaration for "GetRandomDirection" at the top of the program to see this definition
        if (GetRandomDirection(nOldRow, nOldCol, nNewRow, nNewCol, sDirection) != -1)
        {
            // if the spot is the polluted region, the shark dies
            if (nNewRow >= nPollutedRowTop && nNewRow <= nPollutedRowBot &&
                nNewCol >= nPollutedColTop && nNewCol <= nPollutedColBot)
            {
                cout << endl << "shark at row:" << nOldRow << ", col:" << nOldCol << " died cuz he got polluted!";
                NEXTOCEAN[nOldRow][nOldCol].m_MakeItEmpty();
            }
            // if the spot is empty OR a fish - WE CAN MOVE!
            else if (NEXTOCEAN[nNewRow][nNewCol].m_bIsEmpty  || NEXTOCEAN[nNewRow][nNewCol].m_bIsAFish)
            {
                cout << endl << "Moving shark from row:" << nOldRow << ", col:" << nOldCol << " " << sDirection;
                
                // Check if the Shark gets to eat, and set the months to live accordingly
                // if the new spot is a fish - its dinnertime!  Time to recharge
                if (NEXTOCEAN[nNewRow][nNewCol].m_bIsAFish)
                {
                    NEXTOCEAN[nNewRow][nNewCol].m_nMonthsToLive = STARVE;
                    cout << endl << "The shark at row:" << nOldRow << ", col:" << nOldCol << " ate the fish at row:" <<
                    nNewRow << ", col:" << nNewCol << " and now has " << STARVE << " months left!";
                    
                    // Eliminate the fish from the OCEAN array so we dont try to move it later
                    OCEAN[nNewRow][nNewCol].m_MakeItEmpty();
                }
                else
                {
                    NEXTOCEAN[nNewRow][nNewCol].m_nMonthsToLive = NEXTOCEAN[nOldRow][nOldCol].m_nMonthsToLive;
                }
                
                // Make the new square a Shark
                NEXTOCEAN[nNewRow][nNewCol].m_bIsAShark = true;
                NEXTOCEAN[nNewRow][nNewCol].m_bIsAFish = false;
                NEXTOCEAN[nNewRow][nNewCol].m_bIsEmpty = false;
                NEXTOCEAN[nNewRow][nNewCol].m_cAnimalType = 'S';
                
                // Check if we should reproduce, and leave some spawn behind
                int nShouldReproduce = rand()%100;
                if (nShouldReproduce < RSHARK)
                {
                    NEXTOCEAN[nOldRow][nOldCol] = NEXTOCEAN[nNewRow][nNewCol];
                    NEXTOCEAN[nOldRow][nOldCol].m_bIsChild = true;
                    cout << " - Reproduce!";
                }
                else
                {
                    NEXTOCEAN[nOldRow][nOldCol].m_MakeItEmpty(); //  Empty out the "old" square,
                }
            }
        }
    }
}

void GetPollutedRegion()
{
    nPollutedRowTop = -1;
    nPollutedColTop = -1;
    nPollutedRowBot = -1;
    nPollutedColBot = -1;
    
    char cAnswer = ' ';
    
    while(cAnswer != 'Y' && cAnswer != 'N')
    {
        cout << endl << "Do you want to specify a Polluted Region (Y/N)?" << ": ";
        cin >> cAnswer;
        if (toupper(cAnswer) == 'Y')
        {
            while(nPollutedRowTop < 0 || nPollutedRowTop >= MAX_ROW)
            {
                cout << endl << "Please specify the TOP row between 0 and " << MAX_ROW - 1 << ": ";
                cin >> nPollutedRowTop;
            }
            while(nPollutedColTop < 0 || nPollutedColTop >= MAX_COL)
            {
                cout << endl << "Please specify the TOP column between 0 and " << MAX_COL - 1 << ": ";
                cin >> nPollutedColTop;
            }
            while(nPollutedRowBot < nPollutedRowTop || nPollutedRowBot >= MAX_ROW)
            {
                cout << endl << "Please specify the BOTTOM row between " << nPollutedRowTop << " and " << MAX_ROW - 1 << ": ";
                cin >> nPollutedRowBot;
            }
            while(nPollutedColBot < nPollutedColTop || nPollutedColBot >= MAX_COL)
            {
                cout << endl << "Please specify the BOTTOM column between " << nPollutedColTop << " and " << MAX_COL - 1 << ": ";
                cin >> nPollutedColBot;
            }
            break;
        }
        if (toupper(cAnswer) == 'N')
        {
            break;
        }
    }
}

/*************************************************/
/* Methods/Implementation for the Animal Class   */
/*************************************************/

// Constructor for the Animal class
Animal::Animal()
{
    // Initialize the class data members
    m_bIsAShark = false;
    m_bIsAFish = false;
    m_bIsEmpty = true;
    m_cAnimalType = '.';
    m_bIsChild = false;
    m_nMonthsToLive = 0;
    
    // Get a random number, and based on that define what sort of animal this is (shark, fish, or empty)
    int nRandomNumber = rand()%100;
    if (nRandomNumber < PSHARK)
    {
        m_bIsAShark = true;
        m_bIsEmpty = false;
        m_cAnimalType = 'S';
        m_nMonthsToLive = STARVE; // Set initial value to the life cycle for this guy
    }
    else if (nRandomNumber < (PSHARK + PFISH))
    {
        m_bIsAFish = true;
        m_bIsEmpty = false;
        m_cAnimalType = 'F';
    }
}

// Print function for the Animal class
void Animal::m_Print()
{
    char cAnimalType = m_cAnimalType;
    
    if (m_bIsChild == true) // If a child, make it lowercase
        cAnimalType = tolower(m_cAnimalType);
    
    cout << cAnimalType << " ";
}


void Animal::m_MakeItEmpty()
{
    m_bIsEmpty = true;
    m_bIsAFish = false;
    m_bIsAShark = false;
    m_cAnimalType = '.';
    m_bIsChild = false;
    m_nMonthsToLive = 0;
}
