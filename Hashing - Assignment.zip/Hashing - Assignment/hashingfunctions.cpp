#include "hashingfunctions.h"

HashingFunctions::HashingFunctions()
{

}

void HashingFunctions::HashChain(std::list<int> table[], int data){

}

void HashingFunctions::HashLinearProbing(int table[], int data){

}

void HashingFunctions::HashDoubleHashing(int table[], int data){

}

int HashingFunctions::HashOne(int key){

}

int HashingFunctions::HashTwo(int key){

}

int HashingFunctions::DoubleHash(int key, int iteration){

}
