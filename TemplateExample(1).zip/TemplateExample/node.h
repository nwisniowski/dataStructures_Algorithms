#ifndef NODE_H
#define NODE_H

template<class T>
class Node{

public:
    Node(T data);

    T GetData();
private:
    T data_;
    Node<T> *next_;
};

template<class T>
Node<T>::Node(T data){
    this->data_ = data;
    this->next_ = nullptr;
}

template<class T>
T Node<T>::GetData(){
    return this->data_;
}

#endif // NODE_H
