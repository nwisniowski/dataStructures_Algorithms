#include "node.h"
#include "iostream"

int main()
{
    Node<int> *intNode = new Node<int>(5);
    Node<char> *charNode = new Node<char>('a');

    std::cout<<"Data in intNode: "<<intNode->GetData()<<std::endl;
    std::cout<<"Data in charNode: "<<charNode->GetData()<<std::endl;
}
