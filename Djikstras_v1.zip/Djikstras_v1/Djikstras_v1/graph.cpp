#include "graph.h"

//DO NOT TOUCH
Graph::Graph()
{

}

//DO NOT TOUCH
void Graph::AddVertex(int key){
    vertex_list_.push_back(new Vertex(key));
    num_vertices_++;
}

//DO NOT TOUCH
void Graph::AddEdge(char from, char to, int weight){
    Vertex *vfrom = GetVertex(from);
    Vertex *vto = GetVertex(to);
    vfrom->AddEdge(vto, weight);
}

//DO NOT TOUCH
Vertex* Graph::GetVertex(char key){
    int i = 0;
    while(i < num_vertices_){
        if(vertex_list_[i]->GetKey() == key){
            return vertex_list_[i];
        }
        i++;
    }

    AddVertex(key);
    return vertex_list_[i];
}

bool Graph::IsAdjacent(char from, char to){
    Vertex *vfrom = GetVertex(from);

    if(vfrom->HasEdge(to)){
        return true;
    }else{
        return false;
    }
}

void Graph::PrintNeighbors(char vertex){
    Vertex *vfrom = GetVertex(vertex);

    for(int i = 0; i < vfrom->GetNumEdges(); i++){
        std::cout<<vfrom->GetEdge(i)->GetTo()->GetKey()<<" ";
    }
    std::cout<<std::endl;
}

Vertex* Graph::DijkstrasAlgorithm(char start, char end){
    //The current vertex you are working on.
    Vertex* currentVertex = nullptr;

    //How many vertices we've visited.
    int visited = 0;

    //An array that keeps track of the already visited vertices.
    int visitedIndex[6] = {0}; //Compiler issue, set to 6 per professor instruction.
    
    for(int i = 0; i<num_vertices_;i++){
        vertex_list_[i]->SetWeight(INT_MAX);
        visitedIndex[i] = vertex_list_[i]->GetKey();
    }
    
    currentVertex = vertex_list_[0];
    currentVertex->SetWeight(0);
    
    for(int i=0;num_vertices_;i++){
        currentVertex=vertex_list_[i];
        
        if(currentVertex->GetNumEdges()==1){
            Edge* edge=currentVertex->GetEdge(i+1);
            int edgeWeight=edge->GetWeight();
            currentVertex->SetWeight(edgeWeight);
            i++;
//            DijkstrasAlgorithm(i, 5);
        }
        
    }
    
    
//    while(currentVertex!=nullptr){
//        
//    }
    
    return 0;
}
