//
//  main.cpp
//  homework1
//
//  Created by NWisniowski on 2/5/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "homework1.h"

int main(){
//    std::cout<<"Enter an array "<<std::endl;
//    std::cin>>array[input];
//    std::cout<<homework1::reverseArray(input,0);
    std::cout<<homework1::countChange(72, 0)<<std::endl;
//    std::<<cout<<homework1::reverseArray(123, 123);
    

    int n;
    std::cout<<"Enter array ";
    std::cin>>n;
    
    int *arr = new int[n];
    
    
    for(int i=0; i<n; i++)  std::cin>>arr[i];
    
    std::reverse(arr, arr+n);
    
    for(int i=0; i<n; i++)    std::cout<<arr[i]<<" ";
    
    delete[] arr;
    
    return 0;
}
