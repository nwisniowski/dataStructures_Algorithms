//
//  homework1.h
//  homework1
//
//  Created by NWisniowski on 2/5/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#ifndef homework1_h
#define homework1_h

class homework1 {
    
public:
    
    // Q1 functions
    static int countChange(int changeInput, int MaxCoinValue);
    // Going to need two parameters here
    static int changeCounter(int changeInput, int counter);
    // Test functions
    static int countWays(int changeAmount, int MaxCoinValue);
    static int quarterCounter(int changeInput, int numWays);
    static int dimeCounter(int changeInput, int numWays);
    static int nickelCounter(int changeInput, int numWays);
    static int total(int changeInput, int coinTracker[], int maxCoinValue);
    
    // Q2 functions
    int input;
    int array[10];
    static int reverseArray(int *a, int n);
    
private:
    
    // Not using these
    const int QUARTER = 25;
    const int DIME = 10;
    const int NICKEL = 5;
    const int PENNY = 1;
};

#endif /* homework1_h */
