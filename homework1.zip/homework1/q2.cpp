//
//  q2.cpp
//  homework1
//
//  Created by NWisniowski on 2/8/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include "homework1.h"
#include <algorithm>

void reverseArray(int *input, int index) {
    if (index <= 0) return;
    
    std::swap(input[0], input[index-1]);
    reverseArray(++input, index-2);
}
