//
//  q1.cpp
//  homework1
//
//  Created by NWisniowski on 2/5/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <iostream>
#include "homework1.h"

//Function to count ways of making change
int homework1::countChange(int changeInput, int MaxCoinValue){
    if (changeInput==0){ //If input is 0, there is no change
        return 0;
    }
    int ways=0;
    if(changeInput>=25){    //If input is greater than 25.
        ways+=homework1::countChange(changeInput-25, 25);
    }
    
    if (changeInput>=10 && MaxCoinValue<25){  //If change is greater than 10.
        ways+=homework1::countChange(changeInput-10, 10);
    }
    
    if (changeInput>=5 && MaxCoinValue<10){  //If change is greater than 5
        ways+=homework1::countChange(changeInput-5, 5);
//        std::cout<<changeInput<<std::endl;
    }
    return ways+1;    //This handles less than 5
//    return 0;
}
