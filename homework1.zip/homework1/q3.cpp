//
//  q3.cpp
//  homework1
//
//  Created by NWisniowski on 2/8/17.
//  Copyright © 2017 NWisniowski. All rights reserved.
//

#include <stdio.h>
#include "homework1.h"

